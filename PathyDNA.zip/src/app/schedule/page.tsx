'use client';

import { useState, useEffect, useMemo, useCallback } from "react";
import { useRouter } from "next/navigation";
import { 
  Calendar as CalendarIcon, 
  Sparkles, 
  Loader2,
  Zap,
  BookOpen,
  Dumbbell,
  Coffee,
  Library,
  Square,
  CheckSquare,
  ExternalLink,
  Users,
  Wrench,
  Globe,
  TrendingUp,
  Target,
  ShieldAlert
} from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from "@/components/ui/select";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useUser, useDoc, useFirestore } from "@/firebase";
import { doc, setDoc } from "firebase/firestore";
import { AssessmentData } from "@/lib/types";
import { aiScheduleGenerator, AiScheduleOutput } from "@/ai/flows/ai-schedule-generator";
import { generateLocalSchedule } from "@/lib/schedule-algo";
import { toast } from "@/hooks/use-toast";
import { cn } from "@/lib/utils";

const CATEGORY_ICONS = {
  study: <BookOpen className="w-5 h-5 text-indigo-400" />,
  practice: <Zap className="w-5 h-5 text-amber-400" />,
  rest: <Coffee className="w-5 h-5 text-emerald-400" />,
  physical: <Dumbbell className="w-5 h-5 text-rose-400" />,
};

const RESOURCE_ICONS: Record<string, any> = {
  course: <BookOpen className="w-5 h-5" />,
  book: <Zap className="w-5 h-5" />,
  community: <Users className="w-5 h-5" />,
  tool: <Wrench className="w-5 h-5" />,
  website: <Globe className="w-5 h-5" />,
};

export default function SchedulePage() {
  const router = useRouter();
  const { user, loading: authLoading } = useUser();
  const firestore = useFirestore();
  
  const userDocRef = useMemo(() => user ? doc(firestore, 'users', user.uid) : null, [user, firestore]);
  const { data: profileDoc, loading: profileLoading } = useDoc(userDocRef);

  const [assessment, setAssessment] = useState<AssessmentData | null>(null);
  const [schedule, setSchedule] = useState<AiScheduleOutput | null>(null);
  const [completedIds, setCompletedIds] = useState<string[]>([]);
  const [isGenerating, setIsGenerating] = useState(false);
  const [intensity, setIntensity] = useState<'relaxed' | 'balanced' | 'aggressive'>('balanced');
  const [focusGoal, setFocusGoal] = useState("");

  useEffect(() => {
    if (profileDoc) {
      setAssessment(profileDoc.assessment as AssessmentData);
      setCompletedIds(profileDoc.completedTaskIds || []);
      if (profileDoc.savedSchedule) {
        setSchedule(profileDoc.savedSchedule as AiScheduleOutput);
      }
    } else if (!authLoading && !profileLoading) {
      const stored = localStorage.getItem('pathfinder_last_assessment');
      if (stored) {
        setAssessment(JSON.parse(stored) as AssessmentData);
      } else {
        router.push('/assessment');
      }
    }
  }, [profileDoc, authLoading, profileLoading, router]);

  const saveToCloud = useCallback(async (newSchedule: AiScheduleOutput) => {
    if (!user) return;
    try {
      await setDoc(doc(firestore, 'users', user.uid), {
        savedSchedule: newSchedule
      }, { merge: true });
    } catch (e) {
      console.error("Failed to save schedule:", e);
    }
  }, [user, firestore]);

  const handleGenerateAI = async () => {
    if (!assessment) return;
    setIsGenerating(true);
    try {
      const res = await aiScheduleGenerator({
        freeTimePerWeek: assessment.freeTimePerWeek || 10,
        interests: assessment.interests,
        currentSkills: assessment.skills as any,
        primaryGoal: focusGoal || "General Growth",
        intensity: intensity
      });
      setSchedule(res);
      saveToCloud(res);
      toast({
        title: "AI Schedule Synchronized",
        description: "Your tactical trajectory has been updated across all devices."
      });
    } catch (error: any) {
      handleGenerateLocal();
    } finally {
      setIsGenerating(false);
    }
  };

  const handleGenerateLocal = () => {
    if (!assessment) return;
    const res = generateLocalSchedule({
      freeTimePerWeek: assessment.freeTimePerWeek || 10,
      interests: assessment.interests,
      currentSkills: assessment.skills as any,
      primaryGoal: focusGoal || "General Growth",
      intensity: intensity
    });
    setSchedule(res);
    saveToCloud(res);
    toast({
      title: "Local Plan Generated",
      description: "Baseline trajectory initialized while AI processes."
    });
  };

  const toggleTask = async (day: string, idx: number) => {
    const taskId = `${day}-${idx}`;
    const newCompleted = completedIds.includes(taskId)
      ? completedIds.filter(id => id !== taskId)
      : [...completedIds, taskId];
    
    setCompletedIds(newCompleted);
    
    if (user) {
      await setDoc(doc(firestore, 'users', user.uid), {
        completedTaskIds: newCompleted
      }, { merge: true });
    }
  };

  if (authLoading || profileLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="w-10 h-10 animate-spin text-primary" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-muted/20 p-4 md:p-10 pt-24 md:pt-10">
      <div className="max-w-7xl mx-auto space-y-10">
        <header className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-6">
          <div className="space-y-1">
            <h1 className="text-4xl md:text-5xl font-black tracking-tighter gradient-text">Tactical Scheduler</h1>
            <p className="text-muted-foreground font-black uppercase tracking-widest text-xs">Persistently track your weekly discovery tasks.</p>
          </div>
          <Button variant="ghost" className="glass h-12 px-8 font-black uppercase tracking-widest text-xs" onClick={() => router.push('/dashboard')}>
            Back to Dashboard
          </Button>
        </header>

        <div className="grid grid-cols-1 lg:grid-cols-4 gap-10">
          <Card className="lg:col-span-1 glass border-none shadow-3xl h-fit rounded-3xl overflow-hidden">
            <div className="p-1 gradient-bg" />
            <CardHeader>
              <CardTitle className="text-lg font-black uppercase tracking-widest flex items-center gap-2">
                <Target className="w-5 h-5 text-primary" />
                Config
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-8">
              <div className="space-y-3">
                <Label className="font-black text-[10px] uppercase tracking-widest text-muted-foreground">Focus Goal</Label>
                <Input 
                  placeholder="e.g. Fullstack Developer" 
                  className="h-14 glass font-bold rounded-2xl"
                  value={focusGoal}
                  onChange={(e) => setFocusGoal(e.target.value)}
                />
              </div>
              <div className="space-y-3">
                <Label className="font-black text-[10px] uppercase tracking-widest text-muted-foreground">Intensity Index</Label>
                <Select value={intensity} onValueChange={(v: any) => setIntensity(v)}>
                  <SelectTrigger className="h-14 glass font-bold rounded-2xl"><SelectValue /></SelectTrigger>
                  <SelectContent className="rounded-2xl">
                    <SelectItem value="relaxed">Relaxed (4h/day)</SelectItem>
                    <SelectItem value="balanced">Balanced (8h/day)</SelectItem>
                    <SelectItem value="aggressive">Aggressive (12h/day)</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </CardContent>
            <CardFooter className="flex flex-col gap-3 p-8 border-t bg-muted/5">
              <Button className="w-full gradient-bg border-none h-14 font-black uppercase tracking-widest shadow-2xl shadow-primary/30 rounded-2xl glow-primary" onClick={handleGenerateAI} disabled={isGenerating}>
                {isGenerating ? <Loader2 className="w-5 h-5 mr-3 animate-spin" /> : <Sparkles className="w-5 h-5 mr-3" />}
                AI Sync
              </Button>
              <Button variant="outline" className="w-full glass h-14 font-black uppercase tracking-widest rounded-2xl" onClick={handleGenerateLocal} disabled={isGenerating}>
                Instant Plan
              </Button>
            </CardFooter>
          </Card>

          <Card className="lg:col-span-3 glass border-none shadow-3xl overflow-hidden min-h-[700px] flex flex-col rounded-[2.5rem]">
            {!schedule ? (
              <div className="flex-1 flex flex-col items-center justify-center p-16 text-center space-y-6">
                <div className="w-24 h-24 rounded-3xl bg-primary/10 flex items-center justify-center animate-pulse">
                  <CalendarIcon className="w-12 h-12 text-primary/40" />
                </div>
                <div className="space-y-2">
                  <h3 className="text-3xl font-black uppercase tracking-tighter">Initialize Plan</h3>
                  <p className="text-sm text-muted-foreground max-w-sm font-medium leading-relaxed">Use the configuration panel to synchronize your unique skills with a daily tactical execution schedule.</p>
                </div>
              </div>
            ) : (
              <div className="p-0 flex flex-col h-full overflow-hidden">
                <div className="p-10 border-b bg-muted/10 flex flex-col md:flex-row md:items-center justify-between gap-6">
                  <div className="space-y-1">
                    <h2 className="text-2xl font-black uppercase tracking-tighter">{schedule.title}</h2>
                    <p className="text-xs text-muted-foreground font-bold tracking-widest uppercase">{schedule.weeklySummary}</p>
                  </div>
                  <div className="flex items-center gap-4 bg-background/50 p-4 rounded-2xl border">
                    <TrendingUp className="w-6 h-6 text-primary" />
                    <div className="space-y-0.5">
                      <p className="text-[10px] font-black uppercase tracking-widest text-muted-foreground">Execution velocity</p>
                      <p className="text-xl font-black gradient-text">{Math.round((completedIds.length / (schedule.days.length * 4)) * 100)}%</p>
                    </div>
                  </div>
                </div>
                <Tabs defaultValue="Monday" className="w-full flex-1 flex flex-col overflow-hidden">
                  <div className="w-full shrink-0 border-b bg-background/50 overflow-x-auto no-scrollbar">
                    <TabsList className="bg-transparent h-16 p-2 gap-2 flex justify-start min-w-max px-6">
                      {schedule.days.map(day => (
                        <TabsTrigger key={day.day} value={day.day} className="data-[state=active]:gradient-bg data-[state=active]:text-white px-8 h-full rounded-xl font-black uppercase tracking-widest text-[10px]">
                          {day.day}
                        </TabsTrigger>
                      ))}
                      <TabsTrigger value="resources" className="px-8 gap-3 h-full rounded-xl font-black uppercase tracking-widest text-[10px] data-[state=active]:bg-secondary data-[state=active]:text-white">
                        <Library className="w-4 h-4" />
                        Resources
                      </TabsTrigger>
                    </TabsList>
                  </div>
                  <ScrollArea className="flex-1">
                    <div className="p-8 sm:p-10">
                      {schedule.days.map(day => (
                        <TabsContent key={day.day} value={day.day} className="mt-0 space-y-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
                          {day.items.map((item, idx) => (
                            <div 
                              key={idx} 
                              onClick={() => toggleTask(day.day, idx)}
                              className={cn(
                                "group glass border-none p-6 sm:p-8 rounded-3xl flex items-start gap-8 hover:shadow-2xl transition-all cursor-pointer border border-transparent hover:border-primary/20 bg-muted/5",
                                completedIds.includes(`${day.day}-${idx}`) && "opacity-40 grayscale scale-95"
                              )}
                            >
                              <div className="shrink-0 mt-1">
                                {completedIds.includes(`${day.day}-${idx}`) 
                                  ? <div className="w-8 h-8 rounded-xl gradient-bg flex items-center justify-center"><CheckSquare className="w-5 h-5 text-white" /></div>
                                  : <div className="w-8 h-8 rounded-xl border-2 border-primary/30 flex items-center justify-center group-hover:border-primary transition-colors"><Square className="w-5 h-5 text-transparent" /></div>}
                              </div>
                              <div className="flex-1">
                                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-3">
                                  <div className="flex items-center gap-3">
                                    <div className="w-10 h-10 rounded-xl bg-background flex items-center justify-center shadow-sm">
                                      {CATEGORY_ICONS[item.category as keyof typeof CATEGORY_ICONS]}
                                    </div>
                                    <h4 className={cn("font-black text-xl tracking-tight", completedIds.includes(`${day.day}-${idx}`) && "line-through")}>
                                      {item.activity}
                                    </h4>
                                  </div>
                                  <Badge variant="outline" className="font-black text-[10px] uppercase tracking-widest border-primary/20 h-8 px-4 rounded-xl">{item.time}</Badge>
                                </div>
                                <p className="text-sm text-muted-foreground leading-relaxed font-medium">{item.description}</p>
                              </div>
                            </div>
                          ))}
                        </TabsContent>
                      ))}
                      
                      <TabsContent value="resources" className="mt-0 space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                          {schedule.recommendedResources.map((res, idx) => (
                            <div key={idx} className="p-8 rounded-[2.5rem] glass border-none flex items-start gap-6 group hover:shadow-3xl transition-all border border-transparent hover:border-primary/20 bg-muted/5">
                              <div className="w-16 h-16 rounded-2xl bg-primary/10 flex items-center justify-center shrink-0 group-hover:rotate-6 transition-transform">
                                {RESOURCE_ICONS[res.type] || <BookOpen className="w-8 h-8 text-primary" />}
                              </div>
                              <div className="flex-1">
                                <h6 className="font-black text-lg group-hover:text-primary transition-colors flex items-center justify-between">
                                  {res.name}
                                  <ExternalLink className="w-4 h-4 opacity-0 group-hover:opacity-100 transition-opacity" />
                                </h6>
                                <p className="text-xs text-muted-foreground mt-2 font-bold leading-relaxed">{res.description}</p>
                                <Badge variant="secondary" className="mt-4 text-[9px] uppercase tracking-widest px-3 h-6 rounded-lg font-black">{res.type}</Badge>
                              </div>
                            </div>
                          ))}
                        </div>
                        <div className="p-10 rounded-3xl border-4 border-dashed border-primary/20 text-center bg-primary/5">
                          <ShieldAlert className="w-10 h-10 text-primary mx-auto mb-4" />
                          <p className="text-lg font-black text-primary italic tracking-tight">"Quality resources are the fuel for rapid skill acquisition. Use these during your deep work blocks."</p>
                        </div>
                      </TabsContent>
                    </div>
                  </ScrollArea>
                </Tabs>
              </div>
            )}
          </Card>
        </div>
      </div>
    </div>
  );
}

