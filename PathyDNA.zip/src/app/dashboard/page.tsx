'use client';

import { useEffect, useState, useMemo, useCallback, memo } from "react";
import { useRouter } from "next/navigation";
import dynamic from "next/dynamic";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Zap,
  Loader2,
  Eye,
  Rocket,
  CalendarDays,
  ExternalLink,
  BookOpen,
  Users,
  Wrench,
  Globe,
  Info,
  Library,
  Activity,
  Dna,
  ListChecks,
  CheckCircle2,
  Target,
  Sparkles
} from "lucide-react";
import { 
  Dialog, 
  DialogContent, 
  DialogHeader, 
  DialogTitle, 
  DialogDescription,
  DialogFooter
} from "@/components/ui/dialog";
import { ScrollArea } from "@/components/ui/scroll-area";
import { AssessmentData, Career, Sport } from "@/lib/types";
import { MOCK_CAREERS, MOCK_SPORTS } from "@/lib/data-mock";
import { calculateCareerMatch, calculateSportMatch } from "@/lib/scoring";
import { useUser, useFirestore, useDoc } from "@/firebase";
import { doc } from "firebase/firestore";
import { aiRecommendationExplanation } from "@/ai/flows/ai-recommendation-explanation";
import { aiLearningRoadmap, AiLearningRoadmapOutput } from "@/ai/flows/ai-learning-roadmap";
import { aiImprovementPlan, AiImprovementPlanOutput } from "@/ai/flows/ai-improvement-plan";
import { aiVisionBoard } from "@/ai/flows/ai-vision-board";

// Dynamically import heavy chart component to speed up initial load
const RadarDNAChart = dynamic(() => import("@/components/RadarDNAChart"), {
  ssr: false,
  loading: () => <div className="h-[300px] w-full flex items-center justify-center"><Loader2 className="animate-spin text-muted-foreground" /></div>
});

const AI_CACHE: Record<string, any> = {};

const RESOURCE_ICONS: Record<string, any> = {
  course: <BookOpen className="w-4 h-4" />,
  book: <Zap className="w-4 h-4" />,
  community: <Users className="w-4 h-4" />,
  tool: <Wrench className="w-4 h-4" />,
  website: <Globe className="w-4 h-4" />,
};

const MatchCard = memo(({ match, type, onRoadmap, onVision, onExplain }: { 
  match: any, 
  type: 'career' | 'sport',
  onRoadmap: (item: any, type: 'career' | 'sport') => void,
  onVision: (item: any) => void,
  onExplain: (item: any, type: 'career' | 'sport') => void
}) => {
  const isCareer = type === 'career';
  const badgeClass = isCareer ? "bg-primary/10 text-primary" : "bg-accent/10 text-accent-foreground";
  const hoverBorder = isCareer ? "hover:border-primary/20" : "hover:border-accent/20";
  const roadmapBtn = isCareer ? "gradient-bg shadow-primary/20" : "gradient-bg-accent shadow-accent/20";
  const analyzeHover = isCareer ? "hover:bg-primary/5" : "hover:bg-accent/5";

  return (
    <div className={`group glass border-none shadow-sm hover:shadow-md transition-all p-5 sm:p-6 flex flex-col md:flex-row gap-6 rounded-xl border border-transparent ${hoverBorder}`}>
      <div className="flex-1 space-y-4">
        <div className="flex items-center justify-between gap-2">
          <h3 className={`text-lg sm:text-xl font-black group-hover:gradient-text transition-colors truncate`}>{match.item.name}</h3>
          <Badge className={`${badgeClass} border-none shrink-0 font-black`}>{match.score}%</Badge>
        </div>
        <p className="text-sm text-muted-foreground leading-relaxed line-clamp-2 font-medium">{match.item.description}</p>
      </div>
      <div className="grid grid-cols-2 md:flex md:flex-col gap-2 min-w-0 md:min-w-[120px]">
        <Button size="sm" className={`${roadmapBtn} shadow-lg h-10 font-black uppercase tracking-tighter text-xs`} onClick={() => onRoadmap(match.item, type)}>Roadmap</Button>
        <Button size="sm" variant="outline" className={`h-10 border-primary/20 ${analyzeHover} font-black uppercase tracking-tighter text-xs`} onClick={() => onVision(match.item)}>
          <Eye className="w-4 h-4 mr-2" />
          Vision
        </Button>
        <Button size="sm" variant="ghost" className={`${analyzeHover} h-8 font-black text-[10px] uppercase tracking-widest`} onClick={() => onExplain(match.item, type)}>Analysis</Button>
      </div>
    </div>
  );
});
MatchCard.displayName = 'MatchCard';

export default function Dashboard() {
  const router = useRouter();
  const { user, loading: authLoading } = useUser();
  const firestore = useFirestore();
  
  const userDocRef = useMemo(() => user ? doc(firestore, 'users', user.uid) : null, [user, firestore]);
  const { data: profileDoc, loading: profileLoading } = useDoc(userDocRef);

  const [assessment, setAssessment] = useState<AssessmentData | null>(null);
  const [aiResult, setAiResult] = useState<{ title: string, content: any, type: 'explanation' | 'roadmap' | 'plan' | 'vision' } | null>(null);
  const [isAiLoading, setIsAiLoading] = useState(false);

  useEffect(() => {
    if (profileDoc) {
      setAssessment(profileDoc.assessment as AssessmentData);
    } else if (!authLoading && !profileLoading) {
      const stored = localStorage.getItem('pathfinder_last_assessment');
      if (stored) {
        setAssessment(JSON.parse(stored) as AssessmentData);
      } else {
        router.push('/assessment');
      }
    }
  }, [profileDoc, authLoading, profileLoading, router]);

  const careerMatches = useMemo(() => {
    if (!assessment) return [];
    return MOCK_CAREERS.map(c => ({
      item: c,
      score: calculateCareerMatch(assessment, c)
    })).sort((a, b) => b.score - a.score);
  }, [assessment]);

  const sportMatches = useMemo(() => {
    if (!assessment) return [];
    return MOCK_SPORTS.map(s => ({
      item: s,
      score: calculateSportMatch(assessment, s)
    })).sort((a, b) => b.score - a.score);
  }, [assessment]);

  const handleExplain = useCallback(async (item: Career | Sport, type: 'career' | 'sport') => {
    const cacheKey = `explain_${type}_${item.id}`;
    if (AI_CACHE[cacheKey]) {
      setAiResult({ title: `Why ${item.name}?`, content: AI_CACHE[cacheKey], type: 'explanation' });
      return;
    }

    setIsAiLoading(true);
    try {
      const res = await aiRecommendationExplanation({
        userProfile: assessment as any,
        recommendedItem: { ...item, type } as any
      });
      AI_CACHE[cacheKey] = res.explanation;
      setAiResult({ title: `Why ${item.name}?`, content: res.explanation, type: 'explanation' });
    } finally {
      setIsAiLoading(false);
    }
  }, [assessment]);

  const handleRoadmap = useCallback(async (item: Career | Sport, type: 'career' | 'sport') => {
    const cacheKey = `roadmap_${type}_${item.id}`;
    if (AI_CACHE[cacheKey]) {
      setAiResult({ title: AI_CACHE[cacheKey].title, content: AI_CACHE[cacheKey], type: 'roadmap' });
      return;
    }

    setIsAiLoading(true);
    try {
      const res = await aiLearningRoadmap({
        userProfile: assessment as any,
        recommendation: { ...item, type } as any
      });
      AI_CACHE[cacheKey] = res;
      setAiResult({ title: res.title, content: res, type: 'roadmap' });
    } finally {
      setIsAiLoading(false);
    }
  }, [assessment]);

  const handleVision = useCallback(async (item: Career | Sport) => {
    const cacheKey = `vision_${item.id}`;
    if (AI_CACHE[cacheKey]) {
      setAiResult({ title: "Future Manifestation", content: AI_CACHE[cacheKey], type: 'vision' });
      return;
    }

    setIsAiLoading(true);
    try {
      const res = await aiVisionBoard({ targetPath: item.name });
      AI_CACHE[cacheKey] = res;
      setAiResult({ title: "Future Manifestation", content: res, type: 'vision' });
    } finally {
      setIsAiLoading(false);
    }
  }, []);

  const handleImprovementPlan = useCallback(async () => {
    const cacheKey = `improvement_plan_${user?.uid || 'guest'}`;
    if (AI_CACHE[cacheKey]) {
      setAiResult({ title: "Strategic Growth Plan", content: AI_CACHE[cacheKey], type: 'plan' });
      return;
    }

    setIsAiLoading(true);
    try {
      const res = await aiImprovementPlan({
        userSkills: assessment!.skills as any,
        userInterests: assessment!.interests,
        userEducationLevel: assessment!.educationLevel || 'High School',
        careerRecommendations: careerMatches.slice(0, 3).map(m => ({
          name: m.item.name,
          matchPercentage: m.score,
          requiredSkills: m.item.requiredSkills
        })),
        sportRecommendations: sportMatches.slice(0, 3).map(m => ({
          name: m.item.name,
          matchPercentage: m.score,
          fitnessBenefits: (m.item as Sport).fitnessBenefits || 'N/A'
        }))
      });
      AI_CACHE[cacheKey] = res;
      setAiResult({ title: "Strategic Growth Plan", content: res, type: 'plan' });
    } finally {
      setIsAiLoading(false);
    }
  }, [assessment, careerMatches, sportMatches, user]);

  const weeklyProgress = useMemo(() => {
    if (!profileDoc?.completedTaskIds) return 0;
    return Math.min(100, (profileDoc.completedTaskIds.length / 20) * 100);
  }, [profileDoc]);

  const radarData = useMemo(() => {
    if (!assessment) return [];
    return Object.entries(assessment.skills).map(([name, value]) => ({
      subject: name.charAt(0).toUpperCase() + name.slice(1).replace(/([A-Z])/g, ' $1'),
      A: value,
      fullMark: 10,
    }));
  }, [assessment]);

  if (authLoading || profileLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="w-8 h-8 animate-spin text-primary" />
      </div>
    );
  }

  if (!assessment) return null;

  return (
    <div className="min-h-screen bg-muted/20 p-4 md:p-8 pt-20 md:pt-8">
      <div className="max-w-7xl mx-auto space-y-8">
        <header className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
          <div className="space-y-1">
            <h1 className="text-3xl md:text-5xl font-black tracking-tighter gradient-text">PathyDNA Hub</h1>
            <p className="text-sm md:text-base text-muted-foreground font-black flex items-center gap-2 uppercase tracking-widest">
              <Dna className="w-4 h-4 text-primary" />
              Genetic & Skill Analysis for {user?.displayName || 'Elite Candidate'}
            </p>
          </div>
          <div className="grid grid-cols-2 md:flex gap-3 w-full md:w-auto">
            <Button size="sm" variant="outline" className="glass h-12 text-[11px] sm:text-xs px-2 sm:px-6 font-black uppercase tracking-widest" onClick={() => router.push('/schedule')}>
              <CalendarDays className="w-4 h-4 mr-2 text-primary shrink-0" />
              Scheduler
            </Button>
            <Button size="sm" variant="outline" className="glass h-12 text-[11px] sm:text-xs px-2 sm:px-6 font-black uppercase tracking-widest" onClick={handleImprovementPlan}>
              <Zap className="w-4 h-4 mr-2 text-secondary shrink-0" />
              Growth Plan
            </Button>
            <Button size="sm" className="gradient-bg border-none h-12 col-span-2 text-xs glow-primary font-black uppercase tracking-[0.2em]" onClick={() => router.push('/assessment')}>
              Update Profile
            </Button>
          </div>
        </header>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          <div className="space-y-8">
            <Card className="glass border-none shadow-3xl overflow-hidden rounded-3xl">
              <div className="p-1.5 gradient-bg" />
              <CardHeader>
                <CardTitle className="text-lg flex items-center gap-2 font-black uppercase tracking-widest">
                  <Activity className="w-5 h-5 text-primary" />
                  Tactical Velocity
                </CardTitle>
                <CardDescription className="font-medium">Execution speed of weekly goals</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="flex justify-between text-sm font-black">
                  <span>Velocity Index</span>
                  <span className="gradient-text">{Math.round(weeklyProgress)}%</span>
                </div>
                <div className="relative h-4 w-full bg-muted rounded-full overflow-hidden shadow-inner">
                   <div 
                    className="absolute inset-y-0 left-0 gradient-bg transition-all duration-1000 ease-out glow-primary"
                    style={{ width: `${weeklyProgress}%` }}
                   />
                </div>
                <p className="text-[10px] text-muted-foreground font-black uppercase tracking-[0.2em] text-center border-t pt-4">
                  Consistent output scales your potential
                </p>
              </CardContent>
            </Card>

            <Card className="glass border-none shadow-3xl h-fit overflow-hidden rounded-3xl">
              <CardHeader>
                <CardTitle className="text-lg flex items-center gap-2 font-black uppercase tracking-widest">
                  <Dna className="w-5 h-5 text-secondary" />
                  Skill DNA Map
                </CardTitle>
                <CardDescription className="font-medium">Multi-dimensional profile analysis</CardDescription>
              </CardHeader>
              <CardContent>
                <RadarDNAChart data={radarData} />
              </CardContent>
            </Card>
          </div>

          <Card className="lg:col-span-2 glass border-none shadow-3xl overflow-hidden flex flex-col rounded-3xl">
            <Tabs defaultValue="careers" className="w-full flex-1 flex flex-col">
              <CardHeader className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-muted/10 p-8 shrink-0 border-b">
                <div className="space-y-1">
                  <CardTitle className="text-2xl font-black uppercase tracking-tighter">Optimized Trajectory</CardTitle>
                  <CardDescription className="font-medium">Based on your unique biometric & skill DNA</CardDescription>
                </div>
                <TabsList className="bg-background/50 border backdrop-blur-sm self-start h-12 p-1.5 rounded-xl">
                  <TabsTrigger value="careers" className="data-[state=active]:gradient-bg data-[state=active]:text-white font-black uppercase tracking-widest text-[10px] px-6 h-full rounded-lg">Careers</TabsTrigger>
                  <TabsTrigger value="sports" className="data-[state=active]:gradient-bg-accent data-[state=active]:text-white font-black uppercase tracking-widest text-[10px] px-6 h-full rounded-lg">Sports</TabsTrigger>
                </TabsList>
              </CardHeader>
              <CardContent className="pt-8 px-4 sm:px-8 flex-1 overflow-y-auto">
                <TabsContent value="careers" className="space-y-6 mt-0">
                  {careerMatches.slice(0, 3).map((match) => (
                    <MatchCard 
                      key={match.item.id} 
                      match={match} 
                      type="career" 
                      onRoadmap={handleRoadmap} 
                      onVision={handleVision} 
                      onExplain={handleExplain} 
                    />
                  ))}
                </TabsContent>
                <TabsContent value="sports" className="space-y-6 mt-0">
                  {sportMatches.slice(0, 3).map((match) => (
                    <MatchCard 
                      key={match.item.id} 
                      match={match} 
                      type="sport" 
                      onRoadmap={handleRoadmap} 
                      onVision={handleVision} 
                      onExplain={handleExplain} 
                    />
                  ))}
                </TabsContent>
              </CardContent>
            </Tabs>
          </Card>
        </div>
      </div>

      <Dialog open={!!aiResult || isAiLoading} onOpenChange={(open) => !open && setAiResult(null)}>
        <DialogContent className="w-[95vw] sm:max-w-4xl max-h-[90vh] flex flex-col p-0 glass border-none overflow-hidden rounded-3xl">
          <div className="h-2 gradient-bg w-full shrink-0" />
          <div className="p-6 sm:p-10 flex flex-col h-full overflow-hidden">
            <DialogHeader className="mb-8 text-left">
              <DialogTitle className="text-2xl sm:text-4xl font-black uppercase tracking-tighter flex items-center gap-4">
                {isAiLoading ? "Synthesizing AI Insights..." : (
                  <>
                    <Rocket className="w-8 h-8 sm:w-10 sm:h-10 text-primary" />
                    {aiResult?.title}
                  </>
                )}
              </DialogTitle>
              <DialogDescription className="font-black text-[10px] sm:text-xs uppercase tracking-[0.3em] text-primary/60 mt-2">
                {isAiLoading ? "Processing neural trajectory data" : "Personalized Intelligence Engine v2.0"}
              </DialogDescription>
            </DialogHeader>
            
            <ScrollArea className="flex-1 pr-6">
              {isAiLoading ? (
                <div className="h-80 flex flex-col items-center justify-center gap-6">
                  <div className="relative">
                    <Loader2 className="w-20 h-20 animate-spin text-primary opacity-20" />
                    <Dna className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-8 h-8 text-primary animate-pulse" />
                  </div>
                  <p className="text-[11px] font-black uppercase tracking-[0.4em] animate-pulse text-muted-foreground">Calibrating DNA Model...</p>
                </div>
              ) : aiResult?.type === 'vision' ? (
                <div className="space-y-8 pb-4">
                  <div className="relative rounded-[2.5rem] overflow-hidden shadow-3xl border-8 border-background/50 group">
                    <img src={aiResult.content.imageUrl} alt="Future Vision" className="w-full h-auto transition-transform duration-1000 group-hover:scale-105" />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/95 via-black/20 to-transparent flex items-end p-10">
                      <p className="text-white text-2xl sm:text-4xl font-black italic tracking-tighter leading-none">"{aiResult.content.caption}"</p>
                    </div>
                  </div>
                  <div className="p-8 rounded-2xl bg-primary/5 border border-primary/10 text-sm italic font-medium leading-relaxed text-muted-foreground border-l-8 border-l-primary">
                    This AI-generated vision is based on your unique skill DNA and professional goals. Keep it as your North Star as you execute your tactical schedule.
                  </div>
                </div>
              ) : aiResult?.type === 'explanation' ? (
                <div className="prose dark:prose-invert max-w-none pb-4">
                  <div className="text-base sm:text-xl leading-relaxed whitespace-pre-wrap text-foreground/80 font-medium border-l-[6px] border-primary pl-10 py-4 bg-muted/5 rounded-r-2xl">
                    {aiResult.content}
                  </div>
                </div>
              ) : aiResult?.type === 'plan' ? (
                <div className="space-y-10 pb-4">
                  <div className="p-10 rounded-3xl bg-primary/5 border border-primary/10 shadow-inner">
                    <h4 className="text-lg font-black mb-6 flex items-center gap-3 uppercase tracking-[0.2em] text-primary">
                      <Info className="w-6 h-6" />
                      Strategic Summary
                    </h4>
                    <p className="text-base sm:text-lg leading-relaxed text-muted-foreground font-medium">
                      {(aiResult.content as AiImprovementPlanOutput).summary}
                    </p>
                  </div>
                  
                  <div className="grid sm:grid-cols-2 gap-8">
                    <Card className="border-none glass rounded-3xl shadow-xl">
                      <CardHeader>
                        <CardTitle className="text-md flex items-center gap-3 font-black uppercase tracking-widest text-primary">
                          <Target className="w-5 h-5" />
                          Priority Skills
                        </CardTitle>
                      </CardHeader>
                      <CardContent>
                        <ul className="space-y-4">
                          {(aiResult.content as AiImprovementPlanOutput).keySkillsToDevelop.map((skill, idx) => (
                            <li key={idx} className="flex items-start gap-3 text-sm font-bold group">
                              <CheckCircle2 className="w-5 h-5 text-primary shrink-0 mt-0.5 transition-transform group-hover:scale-110" />
                              <span className="group-hover:text-primary transition-colors">{skill}</span>
                            </li>
                          ))}
                        </ul>
                      </CardContent>
                    </Card>

                    <Card className="border-none glass rounded-3xl shadow-xl">
                      <CardHeader>
                        <CardTitle className="text-md flex items-center gap-3 font-black uppercase tracking-widest text-secondary">
                          <Rocket className="w-5 h-5" />
                          Actionable Steps
                        </CardTitle>
                      </CardHeader>
                      <CardContent>
                        <ul className="space-y-4">
                          {(aiResult.content as AiImprovementPlanOutput).actionableSteps.map((step, idx) => (
                            <li key={idx} className="flex items-start gap-3 text-sm font-bold group">
                              <Badge variant="outline" className="shrink-0 font-black h-6 w-6 flex items-center justify-center p-0 rounded-lg group-hover:bg-secondary group-hover:text-white transition-all">{idx + 1}</Badge>
                              <span className="group-hover:text-secondary transition-colors">{step}</span>
                            </li>
                          ))}
                        </ul>
                      </CardContent>
                    </Card>
                  </div>

                  <div className="space-y-6">
                    <h4 className="text-xl font-black flex items-center gap-3 uppercase tracking-widest text-primary">
                      <BookOpen className="w-6 h-6" />
                      Curated DNA Resources
                    </h4>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                      {(aiResult.content as AiImprovementPlanOutput).resourceSuggestions.map((res, idx) => (
                        <div key={idx} className="p-5 rounded-2xl glass border-none flex items-center gap-4 group hover:gradient-bg transition-all duration-300">
                          <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center group-hover:bg-white/20 transition-colors">
                            <ExternalLink className="w-5 h-5 text-primary group-hover:text-white" />
                          </div>
                          <span className="text-sm font-black group-hover:text-white transition-colors">{res}</span>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className="text-center p-12 rounded-[2rem] gradient-bg text-white shadow-3xl shadow-primary/30 glow-primary">
                    <Sparkles className="w-12 h-12 mx-auto mb-6" />
                    <p className="text-xl sm:text-3xl font-black italic tracking-tighter leading-tight">
                      "{(aiResult.content as AiImprovementPlanOutput).motivationalSummary}"
                    </p>
                  </div>
                </div>
              ) : (
                <div className="space-y-12 pb-4">
                  <div className="prose dark:prose-invert max-w-none">
                    <p className="text-xl text-muted-foreground italic leading-relaxed font-medium border-l-[6px] border-primary pl-10">
                      {(aiResult.content as AiLearningRoadmapOutput).introduction}
                    </p>
                  </div>

                  <div className="space-y-8">
                    <h4 className="text-2xl font-black flex items-center gap-3 uppercase tracking-widest text-primary">
                      <ListChecks className="w-8 h-8" />
                      Execution Timeline
                    </h4>
                    <div className="space-y-6">
                      {(aiResult.content as AiLearningRoadmapOutput).steps.map((step, idx) => (
                        <div key={idx} className="relative pl-12 border-l-4 border-primary/20 py-6 group">
                          <div className="absolute left-[-15px] top-6 w-7 h-7 rounded-full gradient-bg border-[6px] border-background flex items-center justify-center shadow-2xl transition-transform group-hover:scale-110" />
                          <div className="flex justify-between items-start gap-4 mb-4">
                            <h5 className="font-black text-xl group-hover:text-primary transition-colors">{step.name}</h5>
                            <Badge className="bg-primary/10 text-primary border-none font-black px-4 h-8 flex items-center">{step.timeline}</Badge>
                          </div>
                          <p className="text-base text-muted-foreground font-medium leading-relaxed mb-6">{step.description}</p>
                          <div className="flex flex-wrap gap-2">
                            {step.resources.map((r, rIdx) => (
                              <Badge key={rIdx} variant="secondary" className="text-[10px] font-black uppercase tracking-widest py-1 px-3 rounded-lg border-primary/10">{r}</Badge>
                            ))}
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className="space-y-8">
                    <h4 className="text-2xl font-black flex items-center gap-3 uppercase tracking-widest text-secondary">
                      <Library className="w-8 h-8" />
                      Foundational Library
                    </h4>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                      {(aiResult.content as AiLearningRoadmapOutput).foundationalResources.map((res, idx) => (
                        <div key={idx} className="p-8 rounded-[2rem] glass border-none flex items-start gap-6 group hover:shadow-3xl transition-all border border-transparent hover:border-primary/20 bg-muted/5">
                          <div className="w-14 h-14 rounded-2xl bg-primary/10 flex items-center justify-center shrink-0 group-hover:rotate-6 transition-transform">
                            {RESOURCE_ICONS[res.type] || <BookOpen className="w-8 h-8 text-primary" />}
                          </div>
                          <div>
                            <h6 className="font-black text-lg group-hover:text-primary transition-colors">{res.title}</h6>
                            <p className="text-xs text-muted-foreground mt-2 font-bold leading-relaxed">{res.description}</p>
                            <Badge variant="outline" className="mt-4 text-[9px] uppercase tracking-widest border-primary/20 text-primary">{res.type}</Badge>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className="p-12 rounded-[2.5rem] border-4 border-dashed border-primary/20 text-center bg-primary/5">
                    <p className="text-xl sm:text-2xl font-black text-primary italic tracking-tighter">
                      {(aiResult.content as AiLearningRoadmapOutput).conclusion}
                    </p>
                  </div>
                </div>
              )}
            </ScrollArea>
            
            <DialogFooter className="mt-10 pt-8 border-t shrink-0">
              <Button size="lg" className="w-full gradient-bg shadow-2xl shadow-primary/40 h-16 text-xl font-black glow-primary uppercase tracking-[0.2em] rounded-2xl" onClick={() => setAiResult(null)}>
                Confirm Execution
              </Button>
            </DialogFooter>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}

