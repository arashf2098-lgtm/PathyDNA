"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Slider } from "@/components/ui/slider";
import { 
  Select, 
  SelectContent, 
  SelectItem, 
  SelectTrigger, 
  SelectValue 
} from "@/components/ui/select";
import { 
  Card, 
  CardContent, 
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { 
  ChevronRight, 
  ChevronLeft, 
  CheckCircle2, 
  Shield,
  Target,
  Sparkles,
  Loader2
} from "lucide-react";
import { AssessmentData, EducationLevel } from "@/lib/types";
import { useUser, useFirestore } from "@/firebase";
import { doc, setDoc } from "firebase/firestore";
import { toast } from "@/hooks/use-toast";
import { cn } from "@/lib/utils";

const STEPS = [
  "Personal Information",
  "Budget & Resources",
  "Skills Assessment",
  "Interests & Preferences",
  "Physical Profile"
];

const INTEREST_OPTIONS = [
  "Technology", "Science", "Business", "Arts", "Sports", 
  "Education", "Healthcare", "Engineering", "Finance", "Entrepreneurship"
];

const SKILL_DESCRIPTIONS: Record<string, string> = {
  mathematics: "Logical reasoning and numerical proficiency.",
  problemSolving: "Ability to decompose and solve complex issues.",
  communication: "Effectiveness in verbal and written exchange.",
  leadership: "Leading teams and making strategic decisions.",
  creativity: "Thinking outside conventional frameworks.",
  programming: "Computational logic and software construction.",
  physicalFitness: "General athletic endurance and strength.",
  coordination: "Hand-eye and full-body motor control.",
  teamwork: "Collaborative efficiency in group settings.",
  discipline: "Consistency and adherence to long-term goals."
};

export default function AssessmentWizard() {
  const router = useRouter();
  const { user } = useUser();
  const firestore = useFirestore();
  const [currentStep, setCurrentStep] = useState(0);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [data, setData] = useState<AssessmentData>({
    skills: {
      mathematics: 5, problemSolving: 5, communication: 5, leadership: 5,
      creativity: 5, programming: 5, physicalFitness: 5, coordination: 5,
      teamwork: 5, discipline: 5
    },
    interests: [],
    preferences: {
      indoorVsOutdoor: 'Both',
      teamVsIndividual: 'Both',
      analyticalVsCreative: 'Both',
      physicalVsMental: 'Both'
    },
    physical: {}
  });

  const progress = ((currentStep + 1) / STEPS.length) * 100;

  const handleNext = async () => {
    if (currentStep < STEPS.length - 1) {
      setCurrentStep(currentStep + 1);
      window.scrollTo({ top: 0, behavior: 'smooth' });
    } else {
      setIsSubmitting(true);
      try {
        localStorage.setItem('pathfinder_last_assessment', JSON.stringify(data));
        
        if (user) {
          await setDoc(doc(firestore, 'users', user.uid), {
            userId: user.uid,
            assessment: data,
            createdAt: new Date().toISOString()
          }, { merge: true });
        }
        
        router.push('/dashboard');
      } catch (error: any) {
        toast({
          variant: "destructive",
          title: "Error saving assessment",
          description: error.message
        });
      } finally {
        setIsSubmitting(false);
      }
    }
  };

  const handleBack = () => {
    if (currentStep > 0) {
      setCurrentStep(currentStep - 1);
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  const updateSkill = (skill: string, value: number[]) => {
    setData(prev => ({
      ...prev,
      skills: { ...prev.skills, [skill]: value[0] }
    }));
  };

  const toggleInterest = (interest: string) => {
    setData(prev => {
      const interests = prev.interests.includes(interest)
        ? prev.interests.filter(i => i !== interest)
        : [...prev.interests, interest];
      return { ...prev, interests };
    });
  };

  return (
    <div className="min-h-screen bg-muted/30 py-12 px-4 flex items-center justify-center">
      <div className="w-full max-w-4xl space-y-8 animate-in fade-in duration-700">
        <div className="text-center space-y-3">
          <h1 className="text-4xl md:text-5xl font-black tracking-tighter uppercase gradient-text">Discovery Assessment</h1>
          <p className="text-muted-foreground font-black uppercase tracking-widest text-[10px] sm:text-xs">
            Step {currentStep + 1}: {STEPS[currentStep]}
          </p>
          <div className="max-w-md mx-auto pt-6 space-y-3">
            <Progress value={progress} className="h-3 shadow-inner bg-muted rounded-full" />
            <div className="flex justify-between text-[9px] text-muted-foreground font-black uppercase tracking-[0.2em] px-1">
              <span>Initialization</span>
              <span>Finalization</span>
            </div>
          </div>
        </div>

        <Card className="glass border-none shadow-3xl overflow-hidden rounded-[2rem]">
          <div className="h-2.5 gradient-bg" />
          <CardContent className="p-8 sm:p-12">
            {currentStep === 0 && (
              <div className="space-y-10 animate-in fade-in slide-in-from-bottom-8 duration-500">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-10">
                  <div className="space-y-4">
                    <Label className="font-black text-xs uppercase tracking-[0.2em] text-primary">Chronological Age</Label>
                    <Input 
                      type="number" 
                      placeholder="e.g. 25" 
                      className="h-14 glass text-lg font-bold px-6"
                      value={data.age || ''}
                      onChange={e => setData({...data, age: parseInt(e.target.value) || 0})}
                    />
                  </div>
                  <div className="space-y-4">
                    <Label className="font-black text-xs uppercase tracking-[0.2em] text-primary">Gender Identity</Label>
                    <Select onValueChange={v => setData({...data, gender: v})}>
                      <SelectTrigger className="h-14 glass text-lg font-bold px-6">
                        <SelectValue placeholder="Select" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="male">Male</SelectItem>
                        <SelectItem value="female">Female</SelectItem>
                        <SelectItem value="non-binary">Non-binary</SelectItem>
                        <SelectItem value="other">Other</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <div className="space-y-4">
                  <Label className="font-black text-xs uppercase tracking-[0.2em] text-primary">Country of Residence</Label>
                  <Input 
                    placeholder="e.g. United Kingdom" 
                    className="h-14 glass text-lg font-bold px-6"
                    value={data.country || ''}
                    onChange={e => setData({...data, country: e.target.value})}
                  />
                </div>
                <div className="space-y-4">
                  <Label className="font-black text-xs uppercase tracking-[0.2em] text-primary">Highest Educational Credential</Label>
                  <Select onValueChange={(v: EducationLevel) => setData({...data, educationLevel: v})}>
                    <SelectTrigger className="h-14 glass text-lg font-bold px-6">
                      <SelectValue placeholder="Select your current level" />
                    </SelectTrigger>
                    <SelectContent>
                      {['Middle School', 'High School', 'College', 'Bachelor', 'Master', 'PhD'].map(lvl => (
                        <SelectItem key={lvl} value={lvl as EducationLevel}>{lvl}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>
            )}

            {currentStep === 1 && (
              <div className="space-y-12 animate-in fade-in slide-in-from-bottom-8 duration-500">
                <div className="space-y-8 p-8 rounded-3xl bg-primary/5 border border-primary/10 shadow-inner">
                  <div className="flex justify-between items-center mb-2">
                    <Label className="font-black text-xs uppercase tracking-[0.2em]">Monthly Hobby Budget</Label>
                    <Badge className="font-mono text-xl py-2 px-4 gradient-bg border-none shadow-lg">${data.monthlyHobbyBudget || 0}</Badge>
                  </div>
                  <Slider 
                    max={2000} 
                    step={50} 
                    value={[data.monthlyHobbyBudget || 0]} 
                    onValueChange={v => setData({...data, monthlyHobbyBudget: v[0]})} 
                  />
                  <p className="text-[10px] text-muted-foreground font-bold uppercase tracking-widest text-center">Equipment, Memberships, & Tactical Learning</p>
                </div>

                <div className="space-y-8 p-8 rounded-3xl bg-accent/5 border border-accent/10 shadow-inner">
                  <div className="flex justify-between items-center mb-2">
                    <Label className="font-black text-xs uppercase tracking-[0.2em]">Total Education Budget</Label>
                    <Badge className="font-mono text-xl py-2 px-4 bg-accent text-accent-foreground border-none shadow-lg">${data.educationBudget || 0}</Badge>
                  </div>
                  <Slider 
                    max={100000} 
                    step={1000} 
                    value={[data.educationBudget || 0]} 
                    onValueChange={v => setData({...data, educationBudget: v[0]})} 
                  />
                  <p className="text-[10px] text-muted-foreground font-bold uppercase tracking-widest text-center">Long-term Degrees & Specializations</p>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                  <div className="flex items-center justify-between p-8 border rounded-3xl glass hover:border-primary/50 transition-all group">
                    <div className="space-y-1">
                      <Label className="font-black uppercase tracking-tighter text-lg">Digital Access</Label>
                      <p className="text-[10px] text-muted-foreground uppercase tracking-[0.2em] font-black group-hover:text-primary transition-colors">High-speed connectivity</p>
                    </div>
                    <Switch checked={data.internetAccess} onCheckedChange={v => setData({...data, internetAccess: v})} />
                  </div>
                  <div className="flex items-center justify-between p-8 border rounded-3xl glass hover:border-primary/50 transition-all group">
                    <div className="space-y-1">
                      <Label className="font-black uppercase tracking-tighter text-lg">Mobility Access</Label>
                      <p className="text-[10px] text-muted-foreground uppercase tracking-[0.2em] font-black group-hover:text-primary transition-colors">Tactical transport</p>
                    </div>
                    <Switch checked={data.transportationAccess} onCheckedChange={v => setData({...data, transportationAccess: v})} />
                  </div>
                </div>

                <div className="space-y-8 p-8 rounded-3xl bg-muted/50 border shadow-inner">
                  <div className="flex justify-between items-center mb-2">
                    <Label className="font-black text-xs uppercase tracking-[0.2em]">Weekly Free Capacity</Label>
                    <Badge variant="outline" className="font-mono text-xl py-2 px-4 border-primary/20">{data.freeTimePerWeek || 0} HOURS</Badge>
                  </div>
                  <Slider 
                    max={168} 
                    step={1} 
                    value={[data.freeTimePerWeek || 0]} 
                    onValueChange={v => setData({...data, freeTimePerWeek: v[0]})} 
                  />
                  <p className="text-[10px] text-muted-foreground font-bold uppercase tracking-widest text-center">Real-world hours for potential synthesis</p>
                </div>
              </div>
            )}

            {currentStep === 2 && (
              <div className="space-y-10 animate-in fade-in slide-in-from-bottom-8 duration-500">
                <div className="text-center mb-10 border-b pb-8 border-primary/10">
                  <p className="text-muted-foreground font-black uppercase tracking-[0.2em] text-[10px]">Be honest. This skill DNA is the core of our matching algorithm.</p>
                </div>
                <div className="grid gap-12">
                  {Object.keys(data.skills).map((skill) => (
                    <div key={skill} className="space-y-5 group">
                      <div className="flex justify-between items-end">
                        <div className="space-y-2">
                          <Label className="capitalize font-black text-2xl group-hover:text-primary transition-all duration-300 tracking-tight">
                            {skill.replace(/([A-Z])/g, ' $1')}
                          </Label>
                          <p className="text-[10px] text-muted-foreground uppercase tracking-[0.15em] font-black">{SKILL_DESCRIPTIONS[skill]}</p>
                        </div>
                        <Badge variant="outline" className="font-mono text-2xl h-14 w-16 flex items-center justify-center border-primary/20 bg-primary/5 rounded-2xl group-hover:scale-110 transition-transform">
                          {data.skills[skill as keyof typeof data.skills]}
                        </Badge>
                      </div>
                      <Slider 
                        max={10} 
                        min={1} 
                        step={1} 
                        value={[data.skills[skill as keyof typeof data.skills]]} 
                        onValueChange={v => updateSkill(skill, v)} 
                      />
                    </div>
                  ))}
                </div>
              </div>
            )}

            {currentStep === 3 && (
              <div className="space-y-16 animate-in fade-in slide-in-from-bottom-8 duration-500">
                <div className="space-y-8">
                  <Label className="font-black text-xs uppercase tracking-[0.3em] flex items-center gap-3 text-primary">
                    <Target className="w-5 h-5" />
                    Domain Alignment
                  </Label>
                  <div className="flex flex-wrap gap-4">
                    {INTEREST_OPTIONS.map(interest => (
                      <Badge 
                        key={interest}
                        variant={data.interests.includes(interest) ? "default" : "outline"}
                        className={cn(
                          "cursor-pointer py-4 px-8 text-sm font-black transition-all rounded-[1.25rem] border-2",
                          data.interests.includes(interest) 
                            ? "shadow-2xl shadow-primary/30 border-transparent scale-105" 
                            : "hover:border-primary/50 text-muted-foreground border-muted hover:text-primary"
                        )}
                        onClick={() => toggleInterest(interest)}
                      >
                        {interest}
                      </Badge>
                    ))}
                  </div>
                </div>

                <div className="grid gap-10">
                  <Label className="font-black text-xs uppercase tracking-[0.3em] flex items-center gap-3 text-primary">
                    <Sparkles className="w-5 h-5" />
                    Operational Biases
                  </Label>
                  {[
                    { label: "Environment Preference", key: "indoorVsOutdoor", options: ["Indoor", "Outdoor", "Both"], color: "primary" },
                    { label: "Collaboration Strategy", key: "teamVsIndividual", options: ["Team", "Individual", "Both"], color: "secondary" },
                    { label: "Cognitive Approach", key: "analyticalVsCreative", options: ["Analytical", "Creative", "Both"], color: "accent" },
                    { label: "Biometric Demand", key: "physicalVsMental", options: ["Physical", "Mental", "Both"], color: "primary" },
                  ].map((pref) => (
                    <div key={pref.key} className="space-y-4">
                      <Label className="text-[10px] font-black uppercase text-muted-foreground tracking-widest">{pref.label}</Label>
                      <div className="flex gap-3">
                        {pref.options.map(opt => (
                          <Button
                            key={opt}
                            variant={data.preferences[pref.key as keyof typeof data.preferences] === opt ? "default" : "outline"}
                            size="lg"
                            className={cn(
                              "flex-1 font-black h-14 rounded-2xl text-xs uppercase tracking-widest transition-all",
                              data.preferences[pref.key as keyof typeof data.preferences] === opt 
                                ? "shadow-2xl scale-[1.02]" 
                                : "hover:border-primary/50"
                            )}
                            onClick={() => setData({
                              ...data, 
                              preferences: { ...data.preferences, [pref.key as keyof typeof data.preferences]: opt as any }
                            })}
                          >
                            {opt}
                          </Button>
                        ))}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {currentStep === 4 && (
              <div className="space-y-12 text-center py-10 animate-in fade-in slide-in-from-bottom-8 duration-500">
                <div className="w-28 h-28 rounded-[2rem] gradient-bg flex items-center justify-center mx-auto mb-10 shadow-3xl rotate-6 animate-pulse">
                  <Shield className="w-14 h-14 text-white" />
                </div>
                <div className="space-y-3">
                  <h3 className="text-3xl sm:text-4xl font-black tracking-tighter uppercase">Final Calibration.</h3>
                  <p className="text-muted-foreground max-w-sm mx-auto font-black uppercase tracking-widest text-[10px] sm:text-xs">
                    Optional musculoskeletal metrics for elite athletic matching.
                  </p>
                </div>
                
                <div className="grid grid-cols-2 gap-10 text-left max-w-lg mx-auto">
                  <div className="space-y-4">
                    <Label className="font-black text-[10px] uppercase tracking-widest text-primary">Height (cm)</Label>
                    <Input type="number" className="h-16 glass text-2xl font-black px-6 rounded-2xl" placeholder="---" onChange={e => setData({...data, physical: {...data.physical, height: parseInt(e.target.value) || 0}})} />
                  </div>
                  <div className="space-y-4">
                    <Label className="font-black text-[10px] uppercase tracking-widest text-primary">Weight (kg)</Label>
                    <Input type="number" className="h-16 glass text-2xl font-black px-6 rounded-2xl" placeholder="---" onChange={e => setData({...data, physical: {...data.physical, weight: parseInt(e.target.value) || 0}})} />
                  </div>
                </div>
                
                <div className="space-y-4 text-left max-w-lg mx-auto">
                  <Label className="font-black text-[10px] uppercase tracking-widest text-primary">Injury History / Physiological Constraints</Label>
                  <Input 
                    placeholder="e.g. Previous ACL surgery, chronic back sensitivity" 
                    className="h-16 glass text-sm font-bold px-6 rounded-2xl"
                    onChange={e => setData({...data, physical: {...data.physical, existingInjuries: [e.target.value]}})} 
                  />
                </div>

                <div className="pt-12 flex flex-col items-center gap-6">
                  <div className="flex gap-2">
                    {[1, 2, 3].map(i => (
                      <div key={i} className="w-2 h-2 rounded-full bg-primary animate-bounce" style={{ animationDelay: `${i * 0.2}s` }} />
                    ))}
                  </div>
                  <p className="text-xs font-black uppercase tracking-[0.4em] text-primary animate-pulse">Synthesis Protocol Ready</p>
                </div>
              </div>
            )}
          </CardContent>
          <div className="flex justify-between p-8 sm:p-12 border-t bg-muted/20">
            <Button variant="ghost" size="lg" className="px-10 h-14 font-black uppercase tracking-widest text-xs" onClick={handleBack} disabled={currentStep === 0 || isSubmitting}>
              <ChevronLeft className="mr-3 w-5 h-5" />
              Back
            </Button>
            <Button className="gradient-bg px-14 h-16 text-lg font-black shadow-3xl shadow-primary/30 uppercase tracking-[0.2em] rounded-2xl" onClick={handleNext} disabled={isSubmitting}>
              {isSubmitting ? (
                <div className="flex items-center gap-3">
                  <Loader2 className="w-6 h-6 animate-spin" />
                  Synthesizing...
                </div>
              ) : (
                <>
                  {currentStep === STEPS.length - 1 ? "Complete Analysis" : "Continue"}
                  <ChevronRight className="ml-3 w-6 h-6" />
                </>
              )}
            </Button>
          </div>
        </Card>
      </div>
    </div>
  );
}

