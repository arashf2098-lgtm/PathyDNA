import { MetadataRoute } from 'next'

/**
 * @fileOverview Dynamic robots.txt generator for PathyDNA.
 * This ensures search engines index your site correctly.
 */
export default function robots(): MetadataRoute.Robots {
  const baseUrl = 'https://pathydna.app'
  
  return {
    rules: {
      userAgent: '*',
      allow: '/',
      disallow: [
        '/dashboard', 
        '/schedule', 
        '/api/',
        '/_next/',
        '/assessment'
      ],
    },
    sitemap: `${baseUrl}/sitemap.xml`,
  }
}
