'use client';

import { useState, useRef, useEffect, useMemo } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { ScrollArea } from '@/components/ui/scroll-area';
import { 
  MessageSquare, 
  X, 
  Send, 
  Sparkles, 
  Loader2, 
  Bot, 
  User,
  Zap,
  CheckCircle2,
  AlertCircle
} from 'lucide-react';
import { aiChatBot, AiChatBotOutput } from '@/ai/flows/ai-chatbot';
import { useUser, useFirestore, useDoc } from '@/firebase';
import { doc, setDoc } from 'firebase/firestore';
import { AssessmentData } from '@/lib/types';
import { cn } from '@/lib/utils';
import { toast } from '@/hooks/use-toast';

interface Message {
  role: 'user' | 'model';
  text: string;
  suggestion?: AiChatBotOutput['suggestedAssessmentUpdate'];
}

export function ChatBot() {
  const [isOpen, setIsOpen] = useState(false);
  const [input, setInput] = useState('');
  const [messages, setMessages] = useState<Message[]>([
    { role: 'model', text: "Hi! I'm Pathy. Want to talk about your career matches or update your schedule?" }
  ]);
  const [isLoading, setIsLoading] = useState(false);
  
  const { user } = useUser();
  const firestore = useFirestore();
  const userDocRef = useMemo(() => user ? doc(firestore, 'users', user.uid) : null, [user, firestore]);
  const { data: profileDoc } = useDoc(userDocRef);
  
  const scrollRef = useRef<HTMLDivElement>(null);

  const assessment = useMemo(() => {
    if (profileDoc?.assessment) return profileDoc.assessment as AssessmentData;
    if (typeof window !== 'undefined') {
      const stored = localStorage.getItem('pathfinder_last_assessment');
      if (stored) return JSON.parse(stored) as AssessmentData;
    }
    return null;
  }, [profileDoc]);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollIntoView({ behavior: 'smooth' });
    }
  }, [messages, isLoading]);

  const handleSend = async () => {
    if (!input.trim() || isLoading) return;

    const userMessage = input.trim();
    setInput('');
    setMessages(prev => [...prev, { role: 'user', text: userMessage }]);
    setIsLoading(true);

    try {
      const history = messages.map(m => ({ role: m.role === 'model' ? 'model' : 'user' as any, text: m.text }));
      
      const res = await aiChatBot({
        history,
        userInput: userMessage,
        currentAssessment: assessment || {}
      });

      setMessages(prev => [...prev, { 
        role: 'model', 
        text: res.response,
        suggestion: res.suggestedAssessmentUpdate
      }]);
    } catch (error: any) {
      toast({
        variant: "destructive",
        title: "Chat Error",
        description: "Pathy is temporarily offline. Please try again in a moment."
      });
    } finally {
      setIsLoading(false);
    }
  };

  const applySuggestion = async (suggestion: NonNullable<AiChatBotOutput['suggestedAssessmentUpdate']>) => {
    if (!user || !assessment) {
      toast({
        title: "Profile update",
        description: "Please log in to permanently save profile updates from chat."
      });
      return;
    }

    const updatedAssessment = {
      ...assessment,
      skills: { ...assessment.skills, ...(suggestion.skills || {}) },
      interests: Array.from(new Set([...assessment.interests, ...(suggestion.interests || [])]))
    };

    try {
      await setDoc(doc(firestore, 'users', user.uid), {
        assessment: updatedAssessment
      }, { merge: true });

      toast({
        title: "Profile Synchronized",
        description: "Pathy has successfully updated your Skill DNA based on our conversation."
      });
      
      setMessages(prev => [...prev, { 
        role: 'model', 
        text: "Done! I've updated your profile. You should see your new matches on the dashboard now! 🚀" 
      }]);
    } catch (error: any) {
      toast({
        variant: "destructive",
        title: "Update Failed",
        description: error.message
      });
    }
  };

  return (
    <div className="fixed bottom-6 right-6 z-[100] flex flex-col items-end">
      {isOpen && (
        <Card className="w-[90vw] sm:w-[400px] h-[500px] mb-4 glass border-none shadow-2xl flex flex-col overflow-hidden animate-in slide-in-from-bottom-4 duration-300">
          <CardHeader className="gradient-bg p-4 flex flex-row items-center justify-between shrink-0">
            <div className="flex items-center gap-2 text-white">
              <div className="w-8 h-8 rounded-lg bg-white/20 flex items-center justify-center">
                <Sparkles className="w-4 h-4" />
              </div>
              <div>
                <CardTitle className="text-sm font-black">Pathy AI</CardTitle>
                <div className="flex items-center gap-1.5">
                  <span className="w-1.5 h-1.5 rounded-full bg-green-400 animate-pulse" />
                  <span className="text-[10px] opacity-80 font-bold uppercase tracking-widest">Online</span>
                </div>
              </div>
            </div>
            <Button variant="ghost" size="icon" className="text-white hover:bg-white/10" onClick={() => setIsOpen(false)}>
              <X className="w-4 h-4" />
            </Button>
          </CardHeader>
          
          <CardContent className="flex-1 overflow-hidden p-0 bg-muted/10">
            <ScrollArea className="h-full p-4">
              <div className="space-y-4">
                {messages.map((msg, i) => (
                  <div key={i} className={cn("flex flex-col", msg.role === 'user' ? "items-end" : "items-start")}>
                    <div className={cn(
                      "max-w-[85%] p-3 rounded-2xl text-sm leading-relaxed",
                      msg.role === 'user' 
                        ? "bg-primary text-primary-foreground rounded-tr-none" 
                        : "glass rounded-tl-none border-none shadow-sm"
                    )}>
                      {msg.text}
                    </div>
                    
                    {msg.suggestion && (
                      <div className="mt-2 w-full max-w-[85%] p-3 rounded-xl bg-accent/10 border border-accent/20 space-y-2 animate-in fade-in zoom-in duration-300">
                        <div className="flex items-center gap-2 text-[10px] font-bold text-accent-foreground uppercase tracking-widest">
                          <Zap className="w-3 h-3" />
                          Suggested Profile Tuning
                        </div>
                        <p className="text-[11px] text-muted-foreground italic">"{msg.suggestion.reasoning}"</p>
                        <Button 
                          size="sm" 
                          variant="secondary" 
                          className="w-full text-xs h-8 font-bold"
                          onClick={() => applySuggestion(msg.suggestion!)}
                        >
                          Apply Tuning
                        </Button>
                      </div>
                    )}
                  </div>
                ))}
                {isLoading && (
                  <div className="flex items-center gap-2 text-muted-foreground">
                    <div className="glass p-2 rounded-xl rounded-tl-none">
                      <Loader2 className="w-4 h-4 animate-spin" />
                    </div>
                  </div>
                )}
                <div ref={scrollRef} />
              </div>
            </ScrollArea>
          </CardContent>

          <CardFooter className="p-3 border-t bg-background shrink-0">
            <form 
              onSubmit={(e) => { e.preventDefault(); handleSend(); }} 
              className="flex w-full gap-2"
            >
              <Input 
                placeholder="Ask about your path..." 
                value={input}
                onChange={(e) => setInput(e.target.value)}
                className="glass border-none h-10 text-xs"
                disabled={isLoading}
              />
              <Button 
                type="submit" 
                size="icon" 
                className="gradient-bg border-none shrink-0 h-10 w-10 shadow-lg shadow-primary/20"
                disabled={isLoading || !input.trim()}
              >
                <Send className="w-4 h-4" />
              </Button>
            </form>
          </CardFooter>
        </Card>
      )}

      <Button 
        size="icon" 
        className={cn(
          "w-14 h-14 rounded-full gradient-bg border-none shadow-2xl shadow-primary/40 hover:scale-110 transition-all duration-300 ring-4 ring-background",
          isOpen && "rotate-90"
        )}
        onClick={() => setIsOpen(!isOpen)}
      >
        {isOpen ? <X className="w-6 h-6" /> : <MessageSquare className="w-6 h-6" />}
      </Button>
    </div>
  );
}
