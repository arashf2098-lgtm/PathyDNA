'use client';

import { useEffect } from 'react';
import { errorEmitter } from '@/firebase/error-emitter';
import { toast } from '@/hooks/use-toast';

export function FirebaseErrorListener() {
  useEffect(() => {
    const unsubscribe = errorEmitter.on('permission-error', (error: any) => {
      // In development, we want to see the full error to debug security rules.
      // In a real app, you might handle this differently for users.
      console.error(error);
      toast({
        variant: 'destructive',
        title: 'Permission Denied',
        description: 'You do not have permission to perform this action. Check console for details.',
      });
      
      // We throw the error so it hits the Next.js error overlay in development
      if (process.env.NODE_ENV === 'development') {
        throw error;
      }
    });

    return () => unsubscribe();
  }, []);

  return null;
}
