'use server';
/**
 * @fileOverview A Genkit flow that generates a personalized weekly schedule.
 *
 * - aiScheduleGenerator - A function that generates a weekly schedule based on user input.
 * - AiScheduleInput - The input type for the aiScheduleGenerator function.
 * - AiScheduleOutput - The return type for the aiScheduleGenerator function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const ScheduleInputSchema = z.object({
  freeTimePerWeek: z.number().describe('Total free hours per week.'),
  interests: z.array(z.string()).describe('List of user interests.'),
  currentSkills: z.record(z.number()).describe('Map of user skills and levels.'),
  primaryGoal: z.string().describe('The career or sport the user is focused on.'),
  intensity: z.enum(['relaxed', 'balanced', 'aggressive']).describe('How intensive the schedule should be.'),
});
export type AiScheduleInput = z.infer<typeof ScheduleInputSchema>;

const ScheduleItemSchema = z.object({
  time: z.string().describe('Time slot (e.g., "08:00 - 09:30").'),
  activity: z.string().describe('The name of the activity.'),
  description: z.string().describe('A brief explanation of what to do.'),
  category: z.enum(['study', 'practice', 'rest', 'physical']).describe('The type of activity.'),
});

const DayScheduleSchema = z.object({
  day: z.string().describe('Name of the day.'),
  items: z.array(ScheduleItemSchema),
});

const RecommendedResourceSchema = z.object({
  name: z.string().describe('Name of the resource'),
  type: z.enum(['course', 'book', 'community', 'tool', 'website']),
  description: z.string().describe('How it helps with the specific goal'),
});

const ScheduleOutputSchema = z.object({
  title: z.string().describe('A title for the schedule.'),
  weeklySummary: z.string().describe('A brief summary of the weekly strategy.'),
  days: z.array(DayScheduleSchema).describe('The day-by-day schedule.'),
  recommendedResources: z.array(RecommendedResourceSchema).describe('Curated resources to support this specific schedule and goal.'),
});
export type AiScheduleOutput = z.infer<typeof ScheduleOutputSchema>;

export async function aiScheduleGenerator(input: AiScheduleInput): Promise<AiScheduleOutput> {
  return aiScheduleFlow(input);
}

const prompt = ai.definePrompt({
  name: 'aiSchedulePrompt',
  input: {schema: ScheduleInputSchema},
  output: {schema: ScheduleOutputSchema},
  prompt: `You are an elite productivity and performance coach. 
Generate a comprehensive weekly schedule and resource list for a user aiming to become successful in: {{{primaryGoal}}}.

Context:
- Total Free Time: {{{freeTimePerWeek}}} hours/week
- Interests: {{#each interests}}{{{this}}}{{#unless @last}}, {{/unless}}{{/each}}
- Intensity: {{{intensity}}}

Task:
1. Create a Monday-Sunday schedule.
2. Provide 3-5 high-impact "Recommended Resources" specifically for mastering {{{primaryGoal}}}. Include courses, books, and tools.
3. Distribute the hours realistically across categories: study, practice, physical, and rest.
`,
});

const aiScheduleFlow = ai.defineFlow(
  {
    name: 'aiScheduleFlow',
    inputSchema: ScheduleInputSchema,
    outputSchema: ScheduleOutputSchema,
  },
  async (input) => {
    const {output} = await prompt(input);
    return output!;
  }
);
