
'use server';
/**
 * @fileOverview Generates a cinematic AI vision of the user in their recommended path.
 */

import { ai } from '@/ai/genkit';
import { z } from 'genkit';

const AiVisionInputSchema = z.object({
  targetPath: z.string().describe('The name of the career or sport to visualize.'),
  userContext: z.string().optional().describe('Additional context about the user for personalization.'),
});
export type AiVisionInput = z.infer<typeof AiVisionInputSchema>;

const AiVisionOutputSchema = z.object({
  imageUrl: z.string().describe('The data URI of the generated image.'),
  caption: z.string().describe('A short, inspiring caption for the vision board.'),
});
export type AiVisionOutput = z.infer<typeof AiVisionOutputSchema>;

export async function aiVisionBoard(input: AiVisionInput): Promise<AiVisionOutput> {
  return aiVisionBoardFlow(input);
}

const aiVisionBoardFlow = ai.defineFlow(
  {
    name: 'aiVisionBoardFlow',
    inputSchema: AiVisionInputSchema,
    outputSchema: AiVisionOutputSchema,
  },
  async (input) => {
    const prompt = `A cinematic, high-resolution, inspiring professional photograph of a ${input.targetPath}. 
    The scene should represent excellence, peak performance, and success in a modern setting. 
    Vibrant lighting, shallow depth of field, 8k resolution.`;

    const { media } = await ai.generate({
      model: 'googleai/imagen-4.0-fast-generate-001',
      prompt,
    });

    if (!media || !media.url) {
      throw new Error('Image generation failed');
    }

    return {
      imageUrl: media.url,
      caption: `Visualizing your future as an elite ${input.targetPath}. This is the path of peak potential.`
    };
  }
);
