
'use server';
/**
 * @fileOverview This file implements a Genkit flow for generating an AI-powered explanation
 * for why a recommended career or sport is a good match for a user's profile.
 *
 * - aiRecommendationExplanation - A function that generates the explanation.
 * - RecommendationExplanationInput - The input type for the aiRecommendationExplanation function.
 * - RecommendationExplanationOutput - The return type for the aiRecommendationExplanation function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

// --- Input Schema Definitions ---

const UserProfileAssessmentSchema = z.object({
  age: z.number().int().positive().describe('User age'),
  gender: z.string().optional().describe('User gender (optional)'),
  country: z.string().describe('User country of residence'),
  educationLevel: z.enum(['Middle School', 'High School', 'College', 'Bachelor', 'Master', 'PhD']).describe('User highest education level'),
  monthlyHobbyBudget: z.number().min(0).describe('User monthly budget for hobbies'),
  educationBudget: z.number().min(0).describe('User budget for education'),
  internetAccess: z.boolean().describe('Does the user have internet access?'),
  transportationAccess: z.boolean().describe('Does the user have transportation access?'),
  freeTimePerWeek: z.number().min(0).describe('User free time per week in hours'),
  skills: z.object({
    Mathematics: z.number().min(1).max(10).describe('Skill level in Mathematics (1-10)'),
    ProblemSolving: z.number().min(1).max(10).describe('Skill level in Problem Solving (1-10)'),
    Communication: z.number().min(1).max(10).describe('Skill level in Communication (1-10)'),
    Leadership: z.number().min(1).max(10).describe('Skill level in Leadership (1-10)'),
    Creativity: z.number().min(1).max(10).describe('Skill level in Creativity (1-10)'),
    Programming: z.number().min(1).max(10).describe('Skill level in Programming (1-10)'),
    PhysicalFitness: z.number().min(1).max(10).describe('Skill level in Physical Fitness (1-10)'),
    Coordination: z.number().min(1).max(10).describe('Skill level in Coordination (1-10)'),
    Teamwork: z.number().min(1).max(10).describe('Skill level in Teamwork (1-10)'),
    Discipline: z.number().min(1).max(10).describe('Skill level in Discipline (1-10)'),
  }).describe('User skill levels (1-10 for each skill)'),
  interests: z.array(z.string()).describe('User interests (e.g., Technology, Sports)'),
  additionalPreferences: z.object({
    IndoorVsOutdoor: z.enum(['Indoor', 'Outdoor', 'Neutral']).describe('Preference for indoor vs outdoor activities'),
    TeamVsIndividual: z.enum(['Team', 'Individual', 'Neutral']).describe('Preference for team vs individual activities'),
    AnalyticalVsCreative: z.enum(['Analytical', 'Creative', 'Neutral']).describe('Preference for analytical vs creative activities'),
    PhysicalVsMental: z.enum(['Physical', 'Mental', 'Neutral']).describe('Preference for physical vs mental activities'),
  }).describe('User activity preferences'),
  physicalInformation: z.object({
    height: z.number().optional().describe('User height in cm (optional)'),
    weight: z.number().optional().describe('User weight in kg (optional)'),
    fitnessLevel: z.string().optional().describe('User self-assessed fitness level (optional)'),
    existingInjuries: z.string().optional().describe('Description of existing injuries (optional)'),
    sportsExperience: z.string().optional().describe('Description of sports experience (optional)'),
  }).optional().describe('Optional physical information about the user'),
});

const CareerRecommendationSchema = z.object({
  type: z.literal('career').describe('Type of recommendation: career'),
  name: z.string().describe('Name of the career'),
  matchPercentage: z.number().min(0).max(100).describe('Match percentage with user profile (0-100)'),
  averageSalary: z.number().describe('Average annual salary for the career'),
  difficulty: z.string().describe('Perceived difficulty of the career'),
  learningTime: z.string().describe('Estimated learning time for the career'),
  growthOutlook: z.string().describe('Growth outlook for the career (e.g., High, Medium, Low)'),
  requiredSkills: z.array(z.string()).describe('Key skills required for the career'),
  description: z.string().describe('Brief description of the career'),
});

const SportRecommendationSchema = z.object({
  type: z.literal('sport').describe('Type of recommendation: sport'),
  name: z.string().describe('Name of the sport'),
  matchPercentage: z.number().min(0).max(100).describe('Match percentage with user profile (0-100)'),
  equipmentCost: z.number().describe('Estimated equipment cost for the sport'),
  fitnessBenefits: z.string().describe('Fitness benefits of the sport'),
  difficulty: z.string().describe('Perceived difficulty of the sport'),
  trainingFrequency: z.string().describe('Recommended training frequency for the sport'),
  description: z.string().describe('Brief description of the sport'),
});

const RecommendationExplanationInputSchema = z.object({
  userProfile: UserProfileAssessmentSchema.describe('The user\'s comprehensive profile based on their assessment.'),
  recommendedItem: z.union([CareerRecommendationSchema, SportRecommendationSchema]).describe('The recommended career or sport for which to generate an explanation.'),
});

export type RecommendationExplanationInput = z.infer<typeof RecommendationExplanationInputSchema>;

// --- Output Schema Definition ---
const RecommendationExplanationOutputSchema = z.object({
  explanation: z.string().describe('A clear, AI-generated explanation for why the recommended item is a good match for the user profile.'),
});
export type RecommendationExplanationOutput = z.infer<typeof RecommendationExplanationOutputSchema>;

// --- Wrapper Function ---
export async function aiRecommendationExplanation(input: RecommendationExplanationInput): Promise<RecommendationExplanationOutput> {
  return generateRecommendationExplanationFlow(input);
}

// --- Genkit Prompt Definition ---
const recommendationExplanationPrompt = ai.definePrompt({
  name: 'recommendationExplanationPrompt',
  input: {schema: RecommendationExplanationInputSchema},
  output: {schema: RecommendationExplanationOutputSchema},
  prompt: `You are an expert career and sports advisor for PathFinder, an AI-powered platform helping users discover suitable paths.
Your task is to provide a clear, concise, and compelling explanation for why the provided recommended item (either a career or a sport) is a good match for the user's profile.
Highlight the specific aspects of the user's skills, interests, budget, education, and physical profile that align with the recommended item.
Structure your explanation logically, making it easy for the user to understand the reasoning behind the suggestion.
The explanation should be positive, encouraging, and tailored to the individual.
Start by acknowledging the match percentage and then elaborate on the key alignment points.

User Profile:
Age: {{{userProfile.age}}}
Gender: {{{userProfile.gender}}}
Country: {{{userProfile.country}}}
Education Level: {{{userProfile.educationLevel}}}
Monthly Hobby Budget: $ {{{userProfile.monthlyHobbyBudget}}}
Education Budget: $ {{{userProfile.educationBudget}}}
Internet Access: {{{userProfile.internetAccess}}}
Transportation Access: {{{userProfile.transportationAccess}}}
Free Time Per Week: {{{userProfile.freeTimePerWeek}}} hours

Skills:
{{#each userProfile.skills}}
  - {{ @key }}: {{ this }}/10
{{/each}}

Interests: {{#each userProfile.interests}}{{{this}}}{{#unless @last}}, {{/unless}}{{/each}}

Preferences:
  - Indoor vs Outdoor: {{{userProfile.additionalPreferences.IndoorVsOutdoor}}}
  - Team vs Individual: {{{userProfile.additionalPreferences.TeamVsIndividual}}}
  - Analytical vs Creative: {{{userProfile.additionalPreferences.AnalyticalVsCreative}}}
  - Physical vs Mental: {{{userProfile.additionalPreferences.PhysicalVsMental}}}

{{#if userProfile.physicalInformation}}
Physical Information (Optional):
  Height: {{{userProfile.physicalInformation.height}}} cm
  Weight: {{{userProfile.physicalInformation.weight}}} kg
  Fitness Level: {{{userProfile.physicalInformation.fitnessLevel}}}
  Existing Injuries: {{{userProfile.physicalInformation.existingInjuries}}}
  Sports Experience: {{{userProfile.physicalInformation.sportsExperience}}}
{{/if}}

---

Recommended Item:
Type: {{{recommendedItem.type}}}
Name: {{{recommendedItem.name}}}
Match Percentage: {{{recommendedItem.matchPercentage}}}%
Description: {{{recommendedItem.description}}}

{{#if (eq recommendedItem.type "career")}}
Career Details:
  Average Salary: $ {{{recommendedItem.averageSalary}}}
  Difficulty: {{{recommendedItem.difficulty}}}
  Learning Time: {{{recommendedItem.learningTime}}}
  Growth Outlook: {{{recommendedItem.growthOutlook}}}
  Required Skills: {{#each recommendedItem.requiredSkills}}{{{this}}}{{#unless @last}}, {{/unless}}{{/each}}
{{else}}
Sport Details:
  Equipment Cost: $ {{{recommendedItem.equipmentCost}}}
  Fitness Benefits: {{{recommendedItem.fitnessBenefits}}}
  Difficulty: {{{recommendedItem.difficulty}}}
  Training Frequency: {{{recommendedItem.trainingFrequency}}}
{{/if}}

Please provide a detailed explanation based on the user's profile and the recommended item, focusing on the strong alignment points.
`,
});

// --- Genkit Flow Definition ---
const generateRecommendationExplanationFlow = ai.defineFlow(
  {
    name: 'generateRecommendationExplanationFlow',
    inputSchema: RecommendationExplanationInputSchema,
    outputSchema: RecommendationExplanationOutputSchema,
  },
  async (input) => {
    const {output} = await recommendationExplanationPrompt(input);
    return output!;
  }
);
