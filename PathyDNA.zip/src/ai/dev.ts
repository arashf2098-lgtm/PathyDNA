
import { config } from 'dotenv';
config();

import '@/ai/flows/ai-improvement-plan.ts';
import '@/ai/flows/ai-learning-roadmap.ts';
import '@/ai/flows/ai-recommendation-explanation.ts';
import '@/ai/flows/ai-schedule-generator.ts';
import '@/ai/flows/ai-chatbot.ts';
import '@/ai/flows/ai-vision-board.ts';
