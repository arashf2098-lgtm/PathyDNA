import { AiScheduleInput, AiScheduleOutput } from '@/ai/flows/ai-schedule-generator';

/**
 * A fast, deterministic algorithm to generate a baseline weekly schedule.
 * This provides instant feedback to the user while AI processes or as a fallback.
 */
export function generateLocalSchedule(input: AiScheduleInput): AiScheduleOutput {
  const days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
  const dailyHours = Math.floor(input.freeTimePerWeek / 7);
  
  const intensityMap = {
    relaxed: { study: 0.4, practice: 0.4, rest: 0.2, physical: 0 },
    balanced: { study: 0.3, practice: 0.4, rest: 0.1, physical: 0.2 },
    aggressive: { study: 0.2, practice: 0.6, rest: 0.05, physical: 0.15 }
  };

  const recommendedResources = [
    {
      name: "Coursera: Foundations of Success",
      type: "course" as const,
      description: "A comprehensive baseline for structured learning in any field."
    },
    {
      name: "The 80/20 Manager by Richard Koch",
      type: "book" as const,
      description: "Learn to focus on the 20% of tasks that drive 80% of your results."
    },
    {
      name: "Focus@Will",
      type: "tool" as const,
      description: "Neuroscience-based music to help you maintain deep focus during study blocks."
    }
  ];

  return {
    title: `Tactical Plan: ${input.primaryGoal}`,
    weeklySummary: `An instantly generated ${input.intensity} routine optimized for ${input.primaryGoal}.`,
    recommendedResources,
    days: days.map(day => {
      const items = [];
      let currentHour = 17; // Start at 5 PM for free time

      if (dailyHours > 0) {
        // Study Slot
        items.push({
          time: `${currentHour}:00 - ${currentHour + 1}:00`,
          activity: `Theory & Research: ${input.primaryGoal}`,
          description: "Focus on the fundamental principles and theoretical knowledge.",
          category: 'study' as const
        });
        currentHour += 1;

        // Practice Slot
        if (dailyHours > 1) {
          items.push({
            time: `${currentHour}:00 - ${currentHour + 2}:00`,
            activity: `Hands-on Practice`,
            description: `Active application of skills related to ${input.interests[0] || 'your goals'}.`,
            category: 'practice' as const
          });
        }
      }

      return { day, items: items.length > 0 ? items : [{
        time: "18:00 - 19:00",
        activity: "Rest & Reflection",
        description: "Consistency is key. Use this time to review your progress.",
        category: "rest" as const
      }] };
    })
  };
}
